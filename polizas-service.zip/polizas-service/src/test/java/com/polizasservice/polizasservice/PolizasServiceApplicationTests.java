package com.polizasservice.polizasservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolizasServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
