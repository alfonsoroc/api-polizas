package com.polizasservice.polizasservice.service;

public class Data {
    private Poliza poliza;
    private Empleado empleado;
    private DetalleArticulo detalleArticulo;



    public void setPoliza(Poliza poliza) {
        this.poliza = poliza;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    public DetalleArticulo getDetalleArticulo() {
        return detalleArticulo;
    }

    public void setDetalleArticulo(DetalleArticulo detalleArticulo) {
        this.detalleArticulo = detalleArticulo;
    }


}
