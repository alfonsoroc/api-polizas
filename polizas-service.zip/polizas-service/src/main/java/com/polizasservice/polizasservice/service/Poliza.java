package com.polizasservice.polizasservice.service;

public class Poliza {
    private int IDPoliza;
    private  float cantidad;

    public int getIDPoliza() {
        return IDPoliza;
    }

    public void setIDPoliza(int IDPoliza) {
        this.IDPoliza = IDPoliza;
    }

    public float getCantidad() {
        return cantidad;
    }

    public void setCantidad(float cantidad) {
        this.cantidad = cantidad;
    }
}
