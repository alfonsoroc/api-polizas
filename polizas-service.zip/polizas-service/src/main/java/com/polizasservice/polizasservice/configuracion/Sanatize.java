package com.polizasservice.polizasservice.configuracion;

import org.springframework.web.util.HtmlUtils;

public class Sanatize {
    public static String sanitize(String input) {
        if (input == null) {
            return null;
        }
        return HtmlUtils.htmlEscape(input);
    }
}
