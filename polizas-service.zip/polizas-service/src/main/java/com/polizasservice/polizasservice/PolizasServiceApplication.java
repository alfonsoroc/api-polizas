package com.polizasservice.polizasservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PolizasServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PolizasServiceApplication.class, args);
	}

}
